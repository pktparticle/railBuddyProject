from django.apps import AppConfig


class PnrConfig(AppConfig):
    name = 'pnr'
